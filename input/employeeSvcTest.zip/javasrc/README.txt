#Contains all *.java source files
#Contains all *.properties files that will go into the jar
#Contains all *.xml files that will go into the jar
#Contains all *.* that will go into the jar except doc*.gif and dog*.jpg
#Contains all *.html files needed by javadoc
#Contains all doc_*.jpg  files needed by javadoc
#Contains all doc_*.gif  files needed by javadoc
#Contains all *.*    files needed by javadoc