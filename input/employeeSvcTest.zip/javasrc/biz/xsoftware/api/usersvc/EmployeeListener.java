package biz.xsoftware.api.usersvc;

import java.util.EventListener;

public interface EmployeeListener extends EventListener {

	public void employeeCreated(Employee employee);
	public void employeeRemoved(Employee employee);
}
