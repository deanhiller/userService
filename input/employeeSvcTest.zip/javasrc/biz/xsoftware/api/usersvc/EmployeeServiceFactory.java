package biz.xsoftware.api.usersvc;

import java.util.Map;

import biz.xsoftware.impl.usersvc.EmployeeServiceFactoryImpl;

public abstract class EmployeeServiceFactory
{
    public static EmployeeServiceFactory createFactory(Map<String, Object> map) {
        EmployeeServiceFactory factory = new EmployeeServiceFactoryImpl();
        factory.configure(map);
        return factory;
    }
    
    protected abstract void configure(Map<String, Object> map);


    public abstract EmployeeService createEmployeeService();    
        
}
