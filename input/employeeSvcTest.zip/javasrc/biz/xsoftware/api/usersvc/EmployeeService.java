package biz.xsoftware.api.usersvc;


public interface EmployeeService
{

	Employee createEmployee(int id, String firstName, String lastName);
	Employee removeEmployee(int id);
	Employee getEmployee(int id);
	
	void addEmployeeListener(EmployeeListener employeeListener);
}
