package biz.xsoftware.impl.usersvc;

import java.util.Map;

import biz.xsoftware.api.usersvc.EmployeeService;
import biz.xsoftware.api.usersvc.EmployeeServiceFactory;

public class EmployeeServiceFactoryImpl extends EmployeeServiceFactory {

	@Override
	protected void configure(Map<String, Object> map) {
		// TODO Auto-generated method stub

	}

	@Override
	public EmployeeService createEmployeeService() {
		return null;
	}

}
