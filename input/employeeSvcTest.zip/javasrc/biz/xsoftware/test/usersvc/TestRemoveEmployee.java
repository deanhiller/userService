package biz.xsoftware.test.usersvc;

import biz.xsoftware.api.usersvc.Employee;
import biz.xsoftware.mock.CalledMethod;


public class TestRemoveEmployee extends TestEmployeeService {

	public TestRemoveEmployee(String name) {
		super(name);
	}
	
	public void testRemove() {
		super.testBasic();
		
		Employee employee = employeeSvc.removeEmployee(id1);
		assertEquals(id1, employee.getId());
		assertEquals(name1, employee.getFirstName());
		
		CalledMethod m = mockUserListener.expect("employeeRemoved");
		Employee removedEmployee = (Employee) m.getAllParams()[0];
		assertEquals(id1, employee.getId());
		assertEquals(name1, removedEmployee.getFirstName());
	}
}
