package biz.xsoftware.test.usersvc;

import junit.framework.TestCase;
import biz.xsoftware.api.usersvc.Employee;
import biz.xsoftware.api.usersvc.EmployeeListener;
import biz.xsoftware.api.usersvc.EmployeeService;
import biz.xsoftware.api.usersvc.EmployeeServiceFactory;
import biz.xsoftware.mock.MockObject;
import biz.xsoftware.mock.MockObjectFactory;

public class TestEmployeeService extends TestCase {

	protected EmployeeService employeeSvc;
	protected int id1 = 4;
	protected int id2 = 5;
	protected String name1 = "dean";
	protected MockObject mockUserListener;

	public TestEmployeeService(String name) {
		super(name);
	}

	@Override
	protected void setUp() throws Exception {
		mockUserListener = MockObjectFactory.createMock(EmployeeListener.class);
		
		
		EmployeeServiceFactory factory = EmployeeServiceFactory.createFactory(null);
		employeeSvc = factory.createEmployeeService();
		
		employeeSvc.addEmployeeListener((EmployeeListener) mockUserListener);
	}

	@Override
	protected void tearDown() throws Exception {
		
	}
	
	public void testBasic() {
		String name2 = "Yun";
		
		Employee employee = employeeSvc.createEmployee(id1, name1, "hiller");
		
		mockUserListener.expect("employeeAdded");
		
		Employee employee2 = employeeSvc.createEmployee(id2, name2, "Xu");
		
		mockUserListener.expect("employeeAdded");
		
		Employee employeeRes = employeeSvc.getEmployee(id1);
		assertEquals(id1, employeeRes.getId());
		assertEquals(name1, employeeRes.getFirstName());
		
		Employee employeeRes2 = employeeSvc.getEmployee(id2);
		assertEquals(id2, employeeRes2.getId());
		assertEquals(name2, employeeRes2.getFirstName());
	}
}
