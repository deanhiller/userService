package biz.xsoftware.test.usersvc;

import biz.xsoftware.api.usersvc.Employee;

public class TestReferences extends TestEmployeeService {

	public TestReferences(String name) {
		super(name);
	}
	
	public void testBasic() {
		int id1 = 4;
		String name1 = "dean";
		
		Employee employee = employeeSvc.createEmployee(id1, name1, "hiller");
		
		employee.setId(5);
		employee.setFirstName("xxx");
		
		
		Employee employee2 = employeeSvc.getEmployee(id1);
		assertEquals(id1, employee2.getId());
		assertEquals(name1, employee2.getFirstName());
		
	}
}
